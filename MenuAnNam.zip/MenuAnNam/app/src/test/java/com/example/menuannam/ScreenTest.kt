package com.example.menuannam

import android.database.sqlite.SQLiteConstraintException
import androidx.compose.ui.test.assertTextEquals
import androidx.compose.ui.test.junit4.StateRestorationTester
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.ComposeNavigator
import androidx.navigation.testing.TestNavHostController
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import com.example.menuannam.data.entity.FlashCard
import com.example.menuannam.data.database.FlashCardDao
import com.example.menuannam.data.database.MenuDatabase
import com.example.menuannam.presentation.navigation.AppNavigation

class DummyFlashCardDao : FlashCardDao {
    override suspend fun getAll(): List<FlashCard> {
        return emptyList<FlashCard>()
    }

    override suspend fun getById(id: Int): FlashCard? {
        return FlashCard(0, "", "")
    }

    override suspend fun findByCards(english: String, vietnamese: String): FlashCard {
        return FlashCard(0, "", "")
    }

    override suspend fun searchCards(searchText: String): List<FlashCard> {
        return emptyList<FlashCard>()
    }

    override suspend fun getCount(): Int {
        return 0
    }

    override suspend fun insert(flashCard: FlashCard): Long {
        return 1L
    }

    override suspend fun insertAll(vararg flashCard: FlashCard) {
    }

    override suspend fun update(id: Int, english: String, vietnamese: String) {
    }

    override suspend fun delete(flashCard: FlashCard) {
    }

    override suspend fun deleteFlashCard(english: String, vietnamese: String) {
    }

    override suspend fun deleteAll() {
    }
}

class DummyFlashCardDaoUnsuccessfulInsert : FlashCardDao {
    override suspend fun getAll(): List<FlashCard> {
        return emptyList<FlashCard>()
    }

    override suspend fun getById(id: Int): FlashCard? {
        return FlashCard(0, "", "")
    }

    override suspend fun findByCards(english: String, vietnamese: String): FlashCard {
        return FlashCard(0, "", "")
    }

    override suspend fun searchCards(searchText: String): List<FlashCard> {
        return emptyList<FlashCard>()
    }

    override suspend fun getCount(): Int {
        return 0
    }

    override suspend fun insert(flashCard: FlashCard): Long {
        throw SQLiteConstraintException()
    }

    override suspend fun insertAll(vararg flashCard: FlashCard) {
        throw SQLiteConstraintException()
    }

    override suspend fun update(id: Int, english: String, vietnamese: String) {
    }

    override suspend fun delete(flashCard: FlashCard) {
    }

    override suspend fun deleteFlashCard(english: String, vietnamese: String) {
    }

    override suspend fun deleteAll() {
    }
}

@RunWith(RobolectricTestRunner::class)
class ScreenTest {
    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun homeStartDestination() {
        val navController = TestNavHostController(ApplicationProvider.getApplicationContext())
        navController.navigatorProvider.addNavigator(ComposeNavigator())
        val dummyFlashCardDao = DummyFlashCardDao()
        
        composeTestRule.setContent {
            AppNavigation(
                navController = navController,
                insertFlashCard = { dummyFlashCardDao.insert(it) },
                getAllFlashCards = { dummyFlashCardDao.getAll() },
                getFlashCardById = { dummyFlashCardDao.getById(it) },
                deleteFlashCard = { dummyFlashCardDao.delete(it) },
                updateFlashCard = { dummyFlashCardDao.update(it.uid, it.englishCard ?: "", it.vietnameseCard ?: "") }
            )
        }
        assertEquals("Main", navController.currentDestination?.route)
    }

    @Test
    fun clickOnStudy() {
        val navController = TestNavHostController(ApplicationProvider.getApplicationContext())
        navController.navigatorProvider.addNavigator(ComposeNavigator())
        val dummyFlashCardDao = DummyFlashCardDao()
        
        composeTestRule.setContent {
            AppNavigation(
                navController = navController,
                insertFlashCard = { dummyFlashCardDao.insert(it) },
                getAllFlashCards = { dummyFlashCardDao.getAll() },
                getFlashCardById = { dummyFlashCardDao.getById(it) },
                deleteFlashCard = { dummyFlashCardDao.delete(it) },
                updateFlashCard = { dummyFlashCardDao.update(it.uid, it.englishCard ?: "", it.vietnameseCard ?: "") }
            )
        }
        
        composeTestRule.onNodeWithContentDescription("Study")
            .assertExists()
            .performClick()
        assertEquals("Study", navController.currentDestination?.route)
    }

    @Test
    fun clickOnAddCard() {
        val navController = TestNavHostController(ApplicationProvider.getApplicationContext())
        navController.navigatorProvider.addNavigator(ComposeNavigator())
        val dummyFlashCardDao = DummyFlashCardDao()

        composeTestRule.setContent {
            AppNavigation(
                navController = navController,
                insertFlashCard = { dummyFlashCardDao.insert(it) },
                getAllFlashCards = { dummyFlashCardDao.getAll() },
                getFlashCardById = { dummyFlashCardDao.getById(it) },
                deleteFlashCard = { dummyFlashCardDao.delete(it) },
                updateFlashCard = { dummyFlashCardDao.update(it.uid, it.englishCard ?: "", it.vietnameseCard ?: "") }
            )
        }
        
        composeTestRule.onNodeWithContentDescription("Add")
            .assertExists()
            .performClick()
        assertEquals("Add", navController.currentDestination?.route)
    }

    @Test
    fun clickOnSearchCards() {
        val navController = TestNavHostController(ApplicationProvider.getApplicationContext())
        navController.navigatorProvider.addNavigator(ComposeNavigator())
        val dummyFlashCardDao = DummyFlashCardDao()

        composeTestRule.setContent {
            AppNavigation(
                navController = navController,
                insertFlashCard = { dummyFlashCardDao.insert(it) },
                getAllFlashCards = { dummyFlashCardDao.getAll() },
                getFlashCardById = { dummyFlashCardDao.getById(it) },
                deleteFlashCard = { dummyFlashCardDao.delete(it) },
                updateFlashCard = { dummyFlashCardDao.update(it.uid, it.englishCard ?: "", it.vietnameseCard ?: "") }
            )
        }
        
        composeTestRule.onNodeWithContentDescription("Search")
            .assertExists()
            .performClick()
        assertEquals("Search", navController.currentDestination?.route)
    }

    @Test
    fun homeScreenRetained_afterConfigChange() {
        val stateRestorationTester = StateRestorationTester(composeTestRule)
        val navController = TestNavHostController(ApplicationProvider.getApplicationContext())
        navController.navigatorProvider.addNavigator(ComposeNavigator())
        val dummyFlashCardDao = DummyFlashCardDao()

        stateRestorationTester.setContent {
            AppNavigation(
                navController = navController,
                insertFlashCard = { dummyFlashCardDao.insert(it) },
                getAllFlashCards = { dummyFlashCardDao.getAll() },
                getFlashCardById = { dummyFlashCardDao.getById(it) },
                deleteFlashCard = { dummyFlashCardDao.delete(it) },
                updateFlashCard = { dummyFlashCardDao.update(it.uid, it.englishCard ?: "", it.vietnameseCard ?: "") }
            )
        }
        
        stateRestorationTester.emulateSavedInstanceStateRestore()
        assertEquals("Main", navController.currentDestination?.route)
    }

    @Test
    fun clickOnAddCardAndBack() {
        val navController = TestNavHostController(ApplicationProvider.getApplicationContext())
        navController.navigatorProvider.addNavigator(ComposeNavigator())
        val dummyFlashCardDao = DummyFlashCardDao()
        
        composeTestRule.setContent {
            AppNavigation(
                navController = navController,
                insertFlashCard = { dummyFlashCardDao.insert(it) },
                getAllFlashCards = { dummyFlashCardDao.getAll() },
                getFlashCardById = { dummyFlashCardDao.getById(it) },
                deleteFlashCard = { dummyFlashCardDao.delete(it) },
                updateFlashCard = { dummyFlashCardDao.update(it.uid, it.englishCard ?: "", it.vietnameseCard ?: "") }
            )
        }
        
        composeTestRule.onNodeWithContentDescription("Add")
            .performClick()
        
        composeTestRule.onNodeWithContentDescription("navigateBack")
            .assertExists()
            .performClick()
        assertEquals("Main", navController.currentDestination?.route)
    }

    @Test
    fun typeOnEnTextInput() {
        val navController = TestNavHostController(ApplicationProvider.getApplicationContext())
        navController.navigatorProvider.addNavigator(ComposeNavigator())
        val dummyFlashCardDao = DummyFlashCardDao()

        composeTestRule.setContent {
            AppNavigation(
                navController = navController,
                insertFlashCard = { dummyFlashCardDao.insert(it) },
                getAllFlashCards = { dummyFlashCardDao.getAll() },
                getFlashCardById = { dummyFlashCardDao.getById(it) },
                deleteFlashCard = { dummyFlashCardDao.delete(it) },
                updateFlashCard = { dummyFlashCardDao.update(it.uid, it.englishCard ?: "", it.vietnameseCard ?: "") }
            )
        }
        
        composeTestRule.onNodeWithContentDescription("Add")
            .performClick()

        val textInput = "house"
        composeTestRule.onNodeWithContentDescription("enTextField")
            .assertExists()
            .performTextInput(textInput)
        composeTestRule.onNodeWithContentDescription("enTextField")
            .assertTextEquals("en", textInput)
    }

    @Test
    fun keepEnglishStringAfterRotation() {
        val navController = TestNavHostController(ApplicationProvider.getApplicationContext())
        navController.navigatorProvider.addNavigator(ComposeNavigator())
        val dummyFlashCardDao = DummyFlashCardDao()

        val stateRestorationTester = StateRestorationTester(composeTestRule)
        stateRestorationTester.setContent {
            AppNavigation(
                navController = navController,
                insertFlashCard = { dummyFlashCardDao.insert(it) },
                getAllFlashCards = { dummyFlashCardDao.getAll() },
                getFlashCardById = { dummyFlashCardDao.getById(it) },
                deleteFlashCard = { dummyFlashCardDao.delete(it) },
                updateFlashCard = { dummyFlashCardDao.update(it.uid, it.englishCard ?: "", it.vietnameseCard ?: "") }
            )
        }
        
        composeTestRule.onNodeWithContentDescription("Add")
            .performClick()

        val textInput = "house"
        composeTestRule.onNodeWithContentDescription("enTextField").assertExists()
            .performTextInput(textInput)

        stateRestorationTester.emulateSavedInstanceStateRestore()
        composeTestRule.onNodeWithContentDescription("enTextField")
            .assertTextEquals("en", textInput)
    }

    @Test
    fun clickOnAddCardSuccessful() {
        val navController = TestNavHostController(ApplicationProvider.getApplicationContext())
        navController.navigatorProvider.addNavigator(ComposeNavigator())
        val dummyFlashCardDao = DummyFlashCardDao()
        
        composeTestRule.setContent {
            AppNavigation(
                navController = navController,
                insertFlashCard = { dummyFlashCardDao.insert(it) },
                getAllFlashCards = { dummyFlashCardDao.getAll() },
                getFlashCardById = { dummyFlashCardDao.getById(it) },
                deleteFlashCard = { dummyFlashCardDao.delete(it) },
                updateFlashCard = { dummyFlashCardDao.update(it.uid, it.englishCard ?: "", it.vietnameseCard ?: "") }
            )
        }
        
        composeTestRule.onNodeWithContentDescription("Add")
            .performClick()

        composeTestRule.onNodeWithContentDescription("Add")
            .assertExists()
            .performClick()

        composeTestRule.onNodeWithContentDescription("Message")
            .assertExists()
            .assertTextEquals("Card added successfully!")
    }

    @Test
    fun clickOnAddCardUnSuccessful() {
        val navController = TestNavHostController(ApplicationProvider.getApplicationContext())
        navController.navigatorProvider.addNavigator(ComposeNavigator())
        val dummyFlashCardDao = DummyFlashCardDaoUnsuccessfulInsert()

        composeTestRule.setContent {
            AppNavigation(
                navController = navController,
                insertFlashCard = { dummyFlashCardDao.insert(it) },
                getAllFlashCards = { dummyFlashCardDao.getAll() },
                getFlashCardById = { dummyFlashCardDao.getById(it) },
                deleteFlashCard = { dummyFlashCardDao.delete(it) },
                updateFlashCard = { dummyFlashCardDao.update(it.uid, it.englishCard ?: "", it.vietnameseCard ?: "") }
            )
        }
        
        composeTestRule.onNodeWithContentDescription("Add")
            .performClick()

        composeTestRule.onNodeWithContentDescription("Add")
            .assertExists()
            .performClick()

        composeTestRule.onNodeWithContentDescription("Message")
            .assertExists()
            .assertTextEquals("Error adding card: android.database.sqlite.SQLiteConstraintException")
    }
}