# BottomBarComponent.md

## Overview
A reusable bottom app bar component that displays messages to users across all screens in the MenuAnNam app. Provides consistent message display in the bottom navigation area.

## Purpose
- **Message Display**: Shows user feedback, status updates, and notifications
- **Consistent UI**: Provides uniform bottom bar across all app screens
- **Accessibility**: Ensures message content is accessible to screen readers
- **Centralized Component**: Reusable component for global message system

## Key Components

### 1. BottomBarComponent Composable
```kotlin
@Composable
fun BottomBarComponent(
    message: String
) {
    BottomAppBar(){
        Text(
            modifier = Modifier
                .fillMaxWidth()
                .semantics { contentDescription = "Message" },
            textAlign = TextAlign.Center,
            text = message
        )
    }
}
```

#### Parameters:
- **message**: String content to display in the bottom bar

#### Features:
- **Full Width**: Text spans entire bottom bar width
- **Center Alignment**: Message text is centered horizontally
- **Semantic Accessibility**: Content description "Message" for screen readers
- **Material Design**: Uses Material3 BottomAppBar component

## Dependencies (Classes it Uses)
- **Material3**: BottomAppBar, Text components
- **Compose Foundation**: fillMaxWidth modifier
- **Compose UI**: TextAlign, semantics for accessibility

## Classes that Depend on This
- **Currently**: Not directly used (Navigator.kt implements inline version)
- **Potentially**: Any screen that needs bottom message display
- **Future Use**: Could replace inline implementation in Navigator

## Design Features

### 1. Material Design Integration
- **BottomAppBar**: Standard Material3 component
- **Consistent Styling**: Follows Material Design guidelines
- **Theme Integration**: Inherits colors from app theme

### 2. Accessibility Support
- **Content Description**: "Message" semantic label
- **Screen Reader**: Text content is properly announced
- **Testing Support**: Enables UI test automation with semantic selectors

### 3. Responsive Layout
- **Full Width**: Adapts to different screen sizes
- **Center Alignment**: Message always centered regardless of length
- **Text Wrapping**: Long messages wrap appropriately

## Current Usage Status

### Not Currently Used
**Note**: This component exists but is not currently used in the app. The Navigator.kt file implements an inline version:

```kotlin
// Current Navigator implementation:
BottomAppBar(
    actions = {
        Text(
            modifier = Modifier
                .fillMaxWidth()
                .semantics { contentDescription = "Message" },
            textAlign = TextAlign.Center,
            text = message
        )
    })
```

### Potential Refactoring
This component could replace the inline implementation to:
- **Reduce Code Duplication**: Centralize bottom bar logic
- **Improve Maintainability**: Single source of truth for bottom bar styling
- **Enable Reusability**: Use across multiple navigation contexts

## Integration Possibilities

### 1. Navigator Integration
```kotlin
// Navigator could use this component:
bottomBar = {
    BottomBarComponent(message = message)
}
```

### 2. Standalone Usage
```kotlin
// Individual screens could use directly:
Scaffold(
    bottomBar = { BottomBarComponent("Screen-specific message") }
) { /* screen content */ }
```

### 3. Enhanced Functionality
```kotlin
// Could be extended with additional features:
BottomBarComponent(
    message = message,
    showDismiss = true,
    messageType = MessageType.ERROR,
    onDismiss = { /* handle dismiss */ }
)
```

## Message Types
Currently supports any string message, commonly used for:
- **Status Updates**: "Card added successfully!"
- **Error Messages**: "Error loading flash cards"
- **Instructions**: "Please, select an option."
- **Loading States**: "Loading flash cards..."

## Styling Considerations

### 1. Text Styling
- **Default Font**: Uses theme typography
- **Center Alignment**: Always horizontally centered
- **Color**: Inherits from Material theme

### 2. Container Styling
- **Background**: Uses BottomAppBar default styling
- **Elevation**: Standard Material elevation
- **Padding**: Default Material spacing

## Future Enhancements

### 1. Message Types
```kotlin
enum class MessageType {
    INFO, SUCCESS, WARNING, ERROR
}

// Enhanced component with styling per type:
BottomBarComponent(
    message = message,
    type = MessageType.ERROR
)
```

### 2. Action Support
```kotlin
// Add action buttons to messages:
BottomBarComponent(
    message = message,
    action = "Undo" to { /* undo action */ }
)
```

### 3. Animation Support
```kotlin
// Animated message transitions:
BottomBarComponent(
    message = message,
    animateChanges = true
)
```

### 4. Dismissible Messages
```kotlin
// Allow users to dismiss messages:
BottomBarComponent(
    message = message,
    dismissible = true,
    onDismiss = { /* clear message */ }
)
```

## Testing Support
- **Semantic Selector**: Can find by contentDescription "Message"
- **Text Assertion**: Can verify message content
- **Visibility Testing**: Can check if message is displayed
- **Accessibility Testing**: Screen reader compatibility

## Architecture Benefits
- **Separation of Concerns**: UI component separate from business logic
- **Reusability**: Can be used across different contexts
- **Maintainability**: Single place to modify bottom bar behavior
- **Consistency**: Ensures uniform message display across app