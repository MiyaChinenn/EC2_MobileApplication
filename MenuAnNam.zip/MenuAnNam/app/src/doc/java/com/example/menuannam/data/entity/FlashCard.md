# CardEntity.md

## Overview
Contains the database entity definition and Data Access Object (DAO) for flash cards. This file defines the data model and all database operations for the app.

## Purpose
- **Data Model**: Defines FlashCard entity structure
- **Database Schema**: Sets up table structure with constraints
- **Data Access**: Provides all CRUD operations for flash cards
- **Type Safety**: Ensures compile-time checking of database operations

## Key Components

### 1. FlashCard Entity
Data class representing a flash card in the database:

```kotlin
@Entity(tableName = "FlashCards", indices = [Index(
    value = ["english_card", "vietnamese_card"],
    unique = true
)])
data class FlashCard(
    @PrimaryKey(autoGenerate = true) val uid: Int,
    @ColumnInfo(name = "english_card") val englishCard: String?,
    @ColumnInfo(name = "vietnamese_card") val vietnameseCard: String?
)
```

#### Properties:
- `uid`: Auto-generated primary key
- `englishCard`: English word/phrase (nullable)
- `vietnameseCard`: Vietnamese translation (nullable)

#### Constraints:
- **Unique Index**: Prevents duplicate cards with same english+vietnamese combination
- **Table Name**: "FlashCards"

### 2. FlashCardDao Interface
Provides all database operations:

#### Read Operations:
- `getAll()`: Get all flash cards
- `getById(id)`: Get specific card by ID
- `findByCards(english, vietnamese)`: Find card by exact match
- `searchCards(searchText)`: Search cards containing text
- `getCount()`: Get total number of cards

#### Write Operations:
- `insert(flashCard)`: Insert single card, returns generated ID
- `insertAll(vararg flashCard)`: Insert multiple cards
- `update(id, english, vietnamese)`: Update card by ID
- `delete(flashCard)`: Delete specific card
- `deleteFlashCard(english, vietnamese)`: Delete by content
- `deleteAll()`: Clear all cards

## Dependencies (Classes it Uses)
- **Room Annotations**: @Entity, @Dao, @Query, @Insert, @Delete, etc.
- **Android Room**: Database framework components

## Classes that Depend on This
- **MenuDatabase**: References FlashCard entity and FlashCardDao
- **MainActivity**: Uses FlashCardDao for database operations
- **All Screen Classes**: Receive FlashCard objects and database operations
- **Test Classes**: Use FlashCard for test data and mock DAOs

## Database Features

### 1. Unique Constraint
- Prevents duplicate flash cards
- Based on combination of english_card + vietnamese_card
- Throws SQLiteConstraintException on duplicates

### 2. Full-Text Search
- `searchCards()` uses LIKE queries
- Searches both english_card and vietnamese_card columns
- Case-insensitive partial matching

### 3. Flexible Operations
- Supports both single and batch operations
- Multiple ways to delete (by object or by content)
- Type-safe parameter binding

### 4. Null Safety
- String fields are nullable to handle edge cases
- Kotlin null safety integrated with Room

## Query Examples

### Search Query
```sql
SELECT * FROM FlashCards 
WHERE english_card LIKE '%searchText%' 
   OR vietnamese_card LIKE '%searchText%'
```

### Update Query
```sql
UPDATE FlashCards 
SET english_card = :english, vietnamese_card = :vietnamese 
WHERE uid = :id
```

### Delete Query
```sql
DELETE FROM FlashCards 
WHERE english_card = :english AND vietnamese_card = :vietnamese
```

## Error Handling
- **Constraint Violations**: Unique index throws SQLiteConstraintException
- **Null Handling**: Nullable fields prevent crashes on empty data
- **Type Safety**: Room prevents SQL injection and type mismatches

## Performance Considerations
- **Indexed Search**: Unique index speeds up duplicate checking
- **Efficient Queries**: Uses primary key for single-item lookups
- **Batch Operations**: `insertAll()` for efficient bulk inserts

## Testing Support
- **Mock-Friendly**: Interface allows easy mocking in tests
- **Test Data**: Simple structure easy to create test instances
- **Verification**: Return types allow verifying operations succeeded