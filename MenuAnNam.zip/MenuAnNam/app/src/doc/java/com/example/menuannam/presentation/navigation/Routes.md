# Routes.md

## Overview
Defines type-safe navigation routes using Kotlin serialization for the Jetpack Compose Navigation system. Contains all screen destinations and their parameter requirements.

## Purpose
- **Type-Safe Navigation**: Uses Kotlin serialization for compile-time route validation
- **Route Definitions**: Central location for all app navigation destinations
- **Parameter Handling**: Defines which routes require parameters and their types
- **Navigation Structure**: Documents the app's navigation graph

## Route Definitions

### 1. Simple Routes (No Parameters)
```kotlin
@Serializable
object HomeRoute        // Main/landing screen

@Serializable  
object AddCardRoute     // Add new flash card screen

@Serializable
object StudyCardsRoute  // Study/review flash cards

@Serializable
object SearchCardsRoute // Search and manage cards
```

### 2. Parameterized Routes
```kotlin
@Serializable
data class ShowCardRoute(val english: String, val vietnamese: String)
// Display specific card content

@Serializable  
data class EditCardRoute(val english: String, val vietnamese: String)
// Edit specific card (currently defined but not implemented)
```

## Navigation Structure

### App Flow
```
HomeRoute (Main Screen)
├── AddCardRoute → Add new cards
├── StudyCardsRoute → Study mode  
├── SearchCardsRoute → Search/manage cards
│   └── ShowCardRoute(english, vietnamese) → View specific card
└── EditCardRoute(english, vietnamese) → Edit card (future feature)
```

## Dependencies (Classes it Uses)
- **Kotlinx.serialization**: For @Serializable annotation
- **Jetpack Compose Navigation**: Uses these routes for navigation

## Classes that Depend on This
- **Navigator.kt**: Uses routes for navigation setup (though currently uses string routes)
- **Test Classes**: Reference route structure for navigation testing
- **Future Navigation Code**: Will use these when migrated from string-based routing

## Route Types

### 1. Object Routes (Singletons)
- **HomeRoute**: No parameters needed
- **AddCardRoute**: Fresh form, no data required  
- **StudyCardsRoute**: Self-contained study mode
- **SearchCardsRoute**: Loads all cards for searching

### 2. Data Class Routes (Parameters)
- **ShowCardRoute**: Requires specific card content to display
- **EditCardRoute**: Requires card content to pre-populate edit form

## Type Safety Benefits

### 1. Compile-Time Validation
- Route parameters are validated at compile time
- Prevents runtime navigation errors
- IDE provides auto-completion and error checking

### 2. Refactoring Safety
- Route changes are caught by compiler
- Find usages works across navigation calls
- Parameter type changes propagate automatically

## Current Implementation Gap
**Note**: The Navigator.kt file currently uses string-based routes ("Main", "Add", etc.) instead of these type-safe routes. This represents a migration opportunity.

### Current Navigator Routes:
- "Main" → should use HomeRoute
- "Add" → should use AddCardRoute  
- "Study" → should use StudyCardsRoute
- "Search" → should use SearchCardsRoute
- "ShowCard/{cardId}" → should use ShowCardRoute

## Migration Path
To use these type-safe routes:
1. Update Navigator.kt to use serializable routes
2. Change composable() calls to use route objects
3. Update navigation calls to use route objects
4. Remove string-based route definitions

## Future Features
**EditCardRoute** is defined but not yet implemented:
- Would allow in-place editing of cards
- Requires edit screen implementation
- Should integrate with existing update operations

## Parameter Handling
Routes with parameters use data classes:
- **english**: English word/phrase from flash card
- **vietnamese**: Vietnamese translation from flash card
- Both parameters are String type
- Used to identify and display specific cards

## Serialization Benefits
- **JSON Serialization**: Routes can be serialized for deep linking
- **State Restoration**: Navigation state can be preserved
- **Testing**: Routes can be easily created for tests
- **Type Safety**: Parameters are strongly typed