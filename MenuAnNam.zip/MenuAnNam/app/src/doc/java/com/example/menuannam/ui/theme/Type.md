# Type.md

## Overview
Defines the typography system for the MenuAnNam app using Material Design 3 text styles. Provides consistent text styling across all app components.

## Purpose
- **Typography System**: Establishes consistent text styling throughout the app
- **Material Design**: Implements Material 3 typography scale
- **Readability**: Ensures proper text sizing and spacing for accessibility
- **Brand Identity**: Maintains consistent text appearance across all screens

## Key Components

### 1. Typography Configuration
```kotlin
val Typography = Typography(
    bodyLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.5.sp
    )
)
```

#### Current Definition:
- **bodyLarge**: Primary text style for body content
- **FontFamily**: Uses system default font
- **FontWeight**: Normal weight (400)
- **Font Size**: 16sp for comfortable reading
- **Line Height**: 24sp for proper spacing (1.5x ratio)
- **Letter Spacing**: 0.5sp for improved readability

### 2. Material 3 Typography Scale
The commented code shows available typography styles:
- **titleLarge**: For main headings (22sp)
- **labelSmall**: For small labels (11sp)
- **bodyLarge**: For main body text (16sp, currently defined)

## Dependencies (Classes it Uses)
- **Material3**: Typography class from Material Design 3
- **Compose UI**: TextStyle, FontFamily, FontWeight from Compose
- **Units**: sp (scaled pixels) for responsive text sizing

## Classes that Depend on This
- **Theme.kt**: Uses Typography in MaterialTheme configuration
- **All UI Components**: Inherit text styles through MaterialTheme.typography
- **ShowCardScreen**: Uses specific typography tokens like headlineSmall, labelLarge

## Typography Usage in App

### 1. Current Usage Examples
```kotlin
// ShowCardScreen uses Material typography tokens:
Text(
    text = "Flash Card #${flashCard!!.uid}",
    style = MaterialTheme.typography.headlineSmall,
    fontWeight = FontWeight.Bold
)

Text(
    text = "English:",
    style = MaterialTheme.typography.labelLarge,
    fontWeight = FontWeight.Medium
)

Text(
    text = flashCard!!.englishCard ?: "N/A",
    style = MaterialTheme.typography.bodyLarge
)
```

### 2. Automatic Inheritance
Most components automatically inherit appropriate text styles:
- **Button Text**: Uses Material button typography
- **TextField Labels**: Uses Material field typography  
- **App Bar Titles**: Uses Material app bar typography

## Material 3 Typography System

### 1. Complete Typography Scale
```kotlin
// Available Material 3 text styles (currently commented out):
displayLarge    = 57sp  // Largest headlines
displayMedium   = 45sp  // Large headlines
displaySmall    = 36sp  // Medium headlines
headlineLarge   = 32sp  // Section headers
headlineMedium  = 28sp  // Subsection headers
headlineSmall   = 24sp  // Small headers (used in ShowCardScreen)
titleLarge      = 22sp  // Card titles
titleMedium     = 16sp  // List item titles
titleSmall      = 14sp  // Small titles
labelLarge      = 14sp  // Primary labels (used in ShowCardScreen)
labelMedium     = 12sp  // Secondary labels
labelSmall      = 11sp  // Small labels
bodyLarge       = 16sp  // Main body text (currently defined)
bodyMedium      = 14sp  // Secondary body text
bodySmall       = 12sp  // Small body text
```

### 2. Semantic Usage
- **Display**: Marketing, hero text
- **Headline**: Page titles, section headers
- **Title**: Subsection titles, card headers
- **Label**: Form labels, captions
- **Body**: Paragraphs, content text

## Current Implementation Status

### 1. Minimal Configuration
**Current State**: Only `bodyLarge` is explicitly defined
```kotlin
val Typography = Typography(
    bodyLarge = TextStyle(...)
    // Other styles use Material 3 defaults
)
```

### 2. Material 3 Defaults
**Fallback Behavior**: Undefined styles use Material 3 default values
- **Advantage**: Consistent with Material Design standards
- **Consideration**: Less customization for brand identity

## Font Configuration

### 1. System Font
```kotlin
fontFamily = FontFamily.Default
```
- **Platform Adaptive**: Uses system default font (Roboto on most Android devices)
- **Accessibility**: Respects user's system font preferences
- **Performance**: No custom font loading required

### 2. Font Weight
```kotlin
fontWeight = FontWeight.Normal  // 400 weight
```
- **Standard Weight**: Normal reading weight
- **Accessibility**: Good readability for most users
- **Flexibility**: Can be overridden for emphasis

## Spacing and Sizing

### 1. Font Size
```kotlin
fontSize = 16.sp  // Scaled pixels
```
- **Responsive**: Scales with user's system font size settings
- **Readable**: Large enough for comfortable reading
- **Standard**: Follows Material Design recommendations

### 2. Line Height
```kotlin
lineHeight = 24.sp  // 150% of font size
```
- **Reading Comfort**: Adequate spacing between lines
- **Accessibility**: Meets WCAG guidelines for line spacing
- **Visual Hierarchy**: Clear text blocks

### 3. Letter Spacing
```kotlin
letterSpacing = 0.5.sp
```
- **Readability**: Slight spacing improves character distinction
- **Material Standard**: Follows Material Design letter spacing
- **Subtle Enhancement**: Not visually distracting

## Integration with Theme

### 1. Theme Application
```kotlin
// In Theme.kt:
MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,  // Applied here
    content = content
)
```

### 2. Component Access
```kotlin
// Components access through MaterialTheme:
Text(
    style = MaterialTheme.typography.bodyLarge,
    text = content
)
```

## Future Enhancements

### 1. Complete Typography Scale
```kotlin
val Typography = Typography(
    displayLarge = TextStyle(...),
    headlineLarge = TextStyle(...),
    titleLarge = TextStyle(...),
    bodyLarge = TextStyle(...),
    labelLarge = TextStyle(...)
    // Define all Material 3 typography tokens
)
```

### 2. Custom Font Integration
```kotlin
val CustomFontFamily = FontFamily(
    Font(R.font.custom_regular, FontWeight.Normal),
    Font(R.font.custom_bold, FontWeight.Bold)
)

val Typography = Typography(
    bodyLarge = TextStyle(
        fontFamily = CustomFontFamily,
        // ... other properties
    )
)
```

### 3. Brand-Specific Styling
```kotlin
val MenuAnNamTypography = Typography(
    // Larger text for educational content
    bodyLarge = TextStyle(fontSize = 18.sp),
    // Custom letter spacing for readability
    labelLarge = TextStyle(letterSpacing = 1.sp)
)
```

### 4. Accessibility Enhancements
```kotlin
val AccessibleTypography = Typography(
    bodyLarge = TextStyle(
        fontSize = 18.sp,        // Larger default size
        lineHeight = 28.sp,      // Increased line spacing
        letterSpacing = 1.sp     // More letter spacing
    )
)
```

## Accessibility Considerations

### 1. Font Scaling
- **Dynamic Sizing**: sp units scale with system font size
- **User Preference**: Respects accessibility font size settings
- **Readability**: Maintains proportions across different sizes

### 2. Line Height
- **WCAG Guidelines**: 150% line height meets accessibility standards
- **Reading Comfort**: Adequate spacing for users with reading difficulties
- **Visual Clarity**: Clear separation between lines of text

### 3. Letter Spacing
- **Character Recognition**: Slight spacing helps with dyslexia
- **Language Support**: Works well with different alphabets
- **Screen Reading**: Doesn't interfere with screen reader pronunciation

## Testing Considerations

### 1. Typography Testing
```kotlin
// Test with different font scales:
composeTestRule.setContent {
    CompositionLocalProvider(LocalDensity provides Density(1.5f)) {
        // Test 150% font scale
        MenuAnNamTheme { /* UI components */ }
    }
}
```

### 2. Accessibility Testing
- **Font Scale Testing**: Test with 100%, 130%, 200% font scales
- **Screen Reader**: Verify text is properly announced
- **High Contrast**: Ensure text remains readable with high contrast