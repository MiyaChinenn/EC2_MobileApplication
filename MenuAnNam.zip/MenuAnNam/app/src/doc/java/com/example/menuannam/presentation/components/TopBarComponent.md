# TopBarComponent.md

## Overview
A reusable top app bar component that provides consistent navigation header with title display and optional back button functionality across the MenuAnNam app.

## Purpose
- **Navigation Header**: Provides top app bar with title and navigation
- **Back Navigation**: Optional back button for hierarchical navigation
- **Consistent UI**: Uniform top bar styling across app screens
- **Material Design**: Implements Material3 design standards

## Key Components

### 1. TopBarComponent Composable
```kotlin
@Composable
fun TopBarComponent(
    title: String,
    showBack: (() -> Unit)? = null,
)
```

#### Parameters:
- **title**: String to display as the app bar title
- **showBack**: Optional callback function for back button (nullable)

#### Features:
- **Centered Title**: Uses CenterAlignedTopAppBar for centered title display
- **Conditional Back Button**: Shows back button only when showBack is provided
- **Material Theming**: Uses app color scheme for consistent styling
- **Experimental API**: Uses Material3 experimental features

### 2. Navigation Integration
```kotlin
navigationIcon = {
    if (showBack != null) {
        TextButton(
            onClick = showBack,
            colors = ButtonDefaults.textButtonColors(
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        ) { Text("Back") }
    }
}
```

#### Back Button Features:
- **Conditional Display**: Only appears when navigation callback provided
- **Text Button Style**: Uses Material3 TextButton component
- **Theme Integration**: Button color matches onPrimary theme color
- **Accessibility**: Standard button with "Back" text label

## Dependencies (Classes it Uses)
- **Material3**: CenterAlignedTopAppBar, TextButton, MaterialTheme
- **Material3 Experimental**: @OptIn for experimental API access
- **ButtonDefaults**: For text button color customization
- **TopAppBarDefaults**: For top app bar color configuration

## Classes that Depend on This
- **Currently**: Not directly used (Navigator.kt implements inline version)
- **Potentially**: Any screen requiring custom top bar configuration
- **Future Use**: Could replace inline implementation in Navigator

## Design Features

### 1. Material Design 3
```kotlin
colors = TopAppBarDefaults.topAppBarColors(
    containerColor = MaterialTheme.colorScheme.primary,
    titleContentColor = MaterialTheme.colorScheme.onPrimary,
    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
)
```

#### Color Scheme:
- **Container**: Primary color background
- **Title**: OnPrimary color for contrast
- **Navigation Icons**: OnPrimary color for consistency
- **Action Icons**: OnPrimary color for uniform appearance

### 2. Accessibility Features
- **Standard Navigation**: Uses platform navigation patterns
- **Screen Reader Support**: Button and title are properly announced
- **Touch Target**: Back button sized for easy interaction
- **High Contrast**: OnPrimary/Primary color combination ensures readability

### 3. Responsive Design
- **Center Alignment**: Title always centered regardless of navigation state
- **Flexible Layout**: Adapts to different title lengths
- **Conditional Elements**: Navigation icon space only used when needed

## Current Usage Status

### Not Currently Used
**Note**: This component exists but is not currently used. Navigator.kt implements a similar inline version:

```kotlin
// Current Navigator implementation:
TopAppBar(
    colors = topAppBarColors(
        containerColor = MaterialTheme.colorScheme.primaryContainer,
        titleContentColor = MaterialTheme.colorScheme.primary,
    ),
    title = { Text("Menu An Nam") },
    navigationIcon = { /* conditional back button */ }
)
```

### Differences from Current Implementation
| Feature | TopBarComponent | Navigator Implementation |
|---------|----------------|--------------------------|
| Title | Dynamic via parameter | Fixed "Menu An Nam" |
| Alignment | CenterAlignedTopAppBar | Regular TopAppBar |
| Colors | Primary/OnPrimary | PrimaryContainer/Primary |
| Back Button | TextButton | Button |

## Integration Possibilities

### 1. Replace Navigator Implementation
```kotlin
// Navigator could use this component:
topBar = {
    TopBarComponent(
        title = "Menu An Nam",
        showBack = if (currentRoute != "Main") { 
            { navController.navigateUp() } 
        } else null
    )
}
```

### 2. Screen-Specific Usage
```kotlin
// Individual screens could customize titles:
Scaffold(
    topBar = { 
        TopBarComponent(
            title = "Add Flash Card",
            showBack = { navController.navigateUp() }
        )
    }
) { /* screen content */ }
```

### 3. Enhanced Functionality
```kotlin
// Could be extended with additional features:
TopBarComponent(
    title = title,
    showBack = backAction,
    actions = listOf(
        TopBarAction("Save") { /* save action */ },
        TopBarAction("Menu") { /* menu action */ }
    )
)
```

## Navigation Patterns

### 1. Hierarchical Navigation
- **Home Screen**: No back button (showBack = null)
- **Detail Screens**: Back button to parent (showBack = { navigateUp() })
- **Deep Links**: Context-aware back navigation

### 2. Modal Navigation
- **Full Screen Dialogs**: Close button instead of back
- **Settings Screens**: Back to previous context
- **Form Screens**: Cancel/Save actions

## Theming Integration

### 1. Color Scheme
- **Primary Background**: Matches app brand colors
- **High Contrast Text**: Ensures accessibility standards
- **Dynamic Theming**: Supports Android 12+ dynamic colors

### 2. Typography
- **Title Style**: Uses Material typography scale
- **Button Text**: Consistent with theme typography
- **Responsive Text**: Scales with system font size

## Future Enhancements

### 1. Action Support
```kotlin
// Add action buttons to top bar:
TopBarComponent(
    title = title,
    showBack = backAction,
    actions = {
        IconButton(onClick = { /* action */ }) {
            Icon(Icons.Default.Search, "Search")
        }
    }
)
```

### 2. Search Integration
```kotlin
// Transform into search bar:
TopBarComponent(
    title = title,
    searchMode = true,
    onSearch = { query -> /* handle search */ }
)
```

### 3. Progress Indication
```kotlin
// Show loading state:
TopBarComponent(
    title = title,
    isLoading = true,
    progress = 0.5f
)
```

### 4. Context Menu
```kotlin
// Add overflow menu:
TopBarComponent(
    title = title,
    menuItems = listOf(
        MenuItem("Settings") { /* action */ },
        MenuItem("Help") { /* action */ }
    )
)
```

## Testing Support
- **Navigation Testing**: Can verify back button functionality
- **Title Verification**: Can assert title text content
- **Accessibility Testing**: Screen reader and navigation testing
- **Visual Testing**: Screenshot testing for layout verification

## Architecture Benefits
- **Consistency**: Uniform top bar across different screen implementations
- **Reusability**: Single component for all top bar needs
- **Maintainability**: Centralized styling and behavior
- **Flexibility**: Optional navigation while maintaining consistency