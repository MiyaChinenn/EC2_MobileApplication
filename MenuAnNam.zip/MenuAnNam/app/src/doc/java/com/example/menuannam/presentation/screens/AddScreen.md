# AddScreen.md

## Overview
The screen where users add new flash cards to their collection. Provides a form with English and Vietnamese input fields and handles card creation with error management.

## Purpose
- **Card Creation**: Allows users to input new English-Vietnamese flash card pairs
- **Form Handling**: Manages text input state with persistence across configuration changes
- **Database Integration**: Inserts new cards through provided database operations
- **User Feedback**: Provides success/error messages and clears form after successful addition

## Key Components

### 1. State Management
```kotlin
var enWord by rememberSaveable {mutableStateOf("")}
var vnWord by rememberSaveable {mutableStateOf("")}
```
- Uses `rememberSaveable` for configuration change persistence
- Maintains separate state for English and Vietnamese inputs
- Automatically saves/restores state during screen rotation

### 2. Form UI
- **English TextField**: Input for English word/phrase with "en" label
- **Vietnamese TextField**: Input for Vietnamese translation with "vn" label  
- **Add Button**: Triggers card creation process
- **Semantic Accessibility**: All components have content descriptions for testing/accessibility

### 3. Card Creation Process
1. User fills in both text fields
2. Clicks "Add" button
3. Creates FlashCard with uid=0 (auto-generated)
4. Calls insertFlashCard operation
5. On success: clears form and shows success message
6. On error: shows error message with exception details

## Dependencies (Classes it Uses)
- **FlashCard**: Entity class for creating new card instances
- **Compose Runtime**: For state management (rememberSaveable, LaunchedEffect)
- **Material3 Components**: TextField, Button, Text for UI
- **Coroutines**: For async database operations

## Classes that Depend on This
- **Navigator.kt**: Includes AddScreen in navigation graph as "Add" route
- **MainActivity**: Provides insertFlashCard lambda function
- **Test Classes**: Test form input, validation, and card creation

## Key Features

### 1. State Persistence
- **Configuration Changes**: Form data survives screen rotation
- **Navigation**: State maintained when navigating away and back
- **Memory Efficiency**: Uses rememberSaveable instead of remember

### 2. Error Handling
```kotlin
try {
    insertFlashCard(FlashCard(uid = 0, englishCard = enWord, vietnameseCard = vnWord))
    // Success: clear form
    enWord = ""
    vnWord = ""
    changeMessage("Card added successfully!")
} catch (e: Exception) {
    // Error: show exception details
    changeMessage("Error adding card: $errorMessage")
}
```

### 3. User Experience
- **Immediate Feedback**: Shows initial message on screen entry
- **Form Clearing**: Automatically clears form after successful addition
- **Error Details**: Shows specific error information for debugging

### 4. Accessibility
- **Content Descriptions**: All interactive elements have semantic descriptions
- **Screen Reader Support**: TextField labels and button text are accessible
- **Testing Support**: Semantic descriptions enable UI testing

## Form Validation
**Current State**: No validation - allows empty fields
**Behavior**: 
- Empty cards can be added to database
- Database constraints may prevent actual insertion
- Error handling catches and displays any database errors

## Database Integration
- **No Direct Database Access**: Uses provided lambda function
- **Async Operations**: Database calls wrapped in coroutine scope
- **Error Propagation**: Catches exceptions from database layer
- **Logging**: Includes debug logging for troubleshooting

## Message System
- **Entry Message**: Shows "Please, add a flash card." when screen loads
- **Success Message**: "Card added successfully!" after insertion
- **Error Messages**: "Error adding card: [exception details]" on failure
- **Global Display**: Messages shown in Navigator's bottom bar

## Testing Considerations
- **Form Input**: Can test text input through content descriptions
- **Button Clicks**: Add button accessible via "Add" content description
- **State Persistence**: Can test configuration change handling
- **Error Scenarios**: Can test with mock DAOs that throw exceptions

## Future Enhancements
- **Input Validation**: Could add empty field checking
- **Character Limits**: Could limit input length
- **Auto-complete**: Could suggest words based on existing cards
- **Batch Input**: Could allow adding multiple cards at once