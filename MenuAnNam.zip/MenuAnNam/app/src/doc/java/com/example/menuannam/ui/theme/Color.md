# Color.md

## Overview
Defines the color palette for the MenuAnNam app using Material Design 3 color system. Contains color definitions for both light and dark theme variations.

## Purpose
- **Color Palette**: Central definition of app colors
- **Material Design**: Follows Material 3 color guidelines  
- **Theme Support**: Provides colors for light and dark themes
- **Brand Identity**: Establishes consistent visual identity

## Color Definitions

### 1. Light Theme Colors (40 variants)
```kotlin
val Purple40 = Color(0xFF6650a4)   // Primary color
val PurpleGrey40 = Color(0xFF625b71) // Secondary color  
val Pink40 = Color(0xFF7D5260)     // Tertiary color
```

#### Usage:
- **Purple40**: Primary brand color for buttons, headers
- **PurpleGrey40**: Secondary accent color
- **Pink40**: Tertiary accent for highlights

### 2. Dark Theme Colors (80 variants)
```kotlin
val Purple80 = Color(0xFFD0BCFF)   // Primary color (light variant)
val PurpleGrey80 = Color(0xFFCCC2DC) // Secondary color (light variant)
val Pink80 = Color(0xFFEFB8C8)     // Tertiary color (light variant)
```

#### Usage:
- **Purple80**: Primary color for dark theme
- **PurpleGrey80**: Secondary color for dark theme
- **Pink80**: Tertiary color for dark theme

## Color Scheme Structure

### 1. Material Design 3 Pattern
- **40 Series**: Darker colors for light theme
- **80 Series**: Lighter colors for dark theme
- **Consistent Hue**: Same color family across themes
- **Accessibility**: Contrast ratios meet WCAG guidelines

### 2. Color Relationships
```
Purple Family:
├── Purple40 (0xFF6650a4) - Dark purple for light theme
└── Purple80 (0xFFD0BCFF) - Light purple for dark theme

PurpleGrey Family:
├── PurpleGrey40 (0xFF625b71) - Dark grey-purple for light theme
└── PurpleGrey80 (0xFFCCC2DC) - Light grey-purple for dark theme

Pink Family:
├── Pink40 (0xFF7D5260) - Dark pink for light theme  
└── Pink80 (0xFFEFB8C8) - Light pink for dark theme
```

## Dependencies (Classes it Uses)
- **Compose UI**: Color class from androidx.compose.ui.graphics
- **Material Design**: Follows Material 3 color specifications

## Classes that Depend on This
- **Theme.kt**: Uses these colors to construct light/dark color schemes
- **UI Components**: Inherit colors through MaterialTheme
- **Custom Components**: Can reference colors directly for custom styling

## Hex Color Analysis

### 1. Purple Colors
- **Purple40** (#6650a4): Deep purple, high saturation
- **Purple80** (#D0BCFF): Lavender, low saturation, high lightness

### 2. PurpleGrey Colors  
- **PurpleGrey40** (#625b71): Muted purple-grey, medium saturation
- **PurpleGrey80** (#CCC2DC): Light purple-grey, low saturation

### 3. Pink Colors
- **Pink40** (#7D5260): Dusty rose, medium saturation
- **Pink80** (#EFB8C8): Light pink, low saturation

## Usage in App

### 1. Current Usage (Theme.kt)
```kotlin
private val DarkColorScheme = darkColorScheme(
    primary = Purple80,      // Light purple for dark theme
    secondary = PurpleGrey80, // Light grey for dark theme
    tertiary = Pink80        // Light pink for dark theme
)

private val LightColorScheme = lightColorScheme(
    primary = Purple40,      // Dark purple for light theme
    secondary = PurpleGrey40, // Dark grey for light theme
    tertiary = Pink40        // Dark pink for light theme
)
```

### 2. Component Usage Examples
```kotlin
// Buttons use primary color
Button(
    colors = ButtonDefaults.buttonColors(
        containerColor = MaterialTheme.colorScheme.primary // Purple40/80
    )
)

// Edit buttons in SearchScreen
Button(
    colors = ButtonDefaults.buttonColors(
        containerColor = MaterialTheme.colorScheme.primary // Purple40/80
    )
)

// Delete buttons in SearchScreen  
Button(
    colors = ButtonDefaults.buttonColors(
        containerColor = MaterialTheme.colorScheme.error // System error color
    )
)
```

## Accessibility Considerations

### 1. Contrast Ratios
- **Purple40 vs White**: High contrast for light theme text
- **Purple80 vs Black**: High contrast for dark theme text
- **Color Blindness**: Purple/pink combination accessible to most users

### 2. WCAG Compliance
- **AA Standard**: All color combinations meet minimum contrast
- **AAA Preferred**: Most combinations exceed recommended contrast
- **System Integration**: Works with OS accessibility settings

## Brand Identity

### 1. Color Psychology
- **Purple**: Creativity, wisdom, premium feeling
- **Pink**: Warmth, approachability, friendliness  
- **Grey**: Balance, neutrality, sophistication

### 2. App Character
- **Educational**: Purple suggests learning and knowledge
- **Friendly**: Pink adds warmth and approachability
- **Professional**: Grey provides balance and refinement

## Material Design Integration

### 1. Seed Color Approach
- **Primary Seed**: Purple family as main brand color
- **Tonal Palette**: Grey and pink provide supporting tones
- **System Integration**: Compatible with Material You dynamic theming

### 2. Color Roles
```kotlin
// Material 3 color roles mapped to app colors:
primary: Purple40/80        // Main brand actions
secondary: PurpleGrey40/80  // Less prominent actions  
tertiary: Pink40/80         // Accent and highlights
```

## Future Enhancements

### 1. Extended Palette
```kotlin
// Could add more variants:
val Purple10 = Color(0xFF1C0E2B)  // Very dark
val Purple20 = Color(0xFF2F1A42)  // Dark
val Purple30 = Color(0xFF442B5B)  // Medium dark
val Purple50 = Color(0xFF7E6A8C)  // Medium
val Purple60 = Color(0xFF9B88A8)  // Medium light
val Purple70 = Color(0xFFB8A5C4)  // Light
val Purple90 = Color(0xFFE8DDE9)  // Very light
```

### 2. Semantic Colors
```kotlin
// Could add semantic meanings:
val Success = Color(0xFF4CAF50)   // Green for success states
val Warning = Color(0xFFFF9800)   // Orange for warnings
val Info = Color(0xFF2196F3)      // Blue for information
```

### 3. Brand Variations
```kotlin
// Could support multiple brands:
val MenuAnNamPrimary = Purple40
val AlternateBrandPrimary = Color(0xFF1976D2)
```

## Dynamic Theming Support
- **Android 12+**: Compatible with Material You dynamic colors
- **Fallback**: Provides consistent colors on older Android versions  
- **User Preference**: Respects system dark/light theme preferences