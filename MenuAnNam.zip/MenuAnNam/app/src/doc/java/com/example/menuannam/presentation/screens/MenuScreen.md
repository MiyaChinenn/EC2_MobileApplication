# MenuScreen.md

## Overview
The main/home screen of the MenuAnNam flash card app. Provides navigation buttons to access the app's three main features: Study, Add, and Search.

## Purpose
- **Navigation Hub**: Central starting point for accessing all app features
- **User Onboarding**: First screen users see with clear action options
- **Feature Discovery**: Simple interface showcasing available functionality
- **Accessibility**: Fully accessible navigation with semantic descriptions

## Key Components

### 1. MenuAnNam Composable Function
```kotlin
@Composable
fun MenuAnNam(
    onAdd: () -> Unit,
    onStudy: () -> Unit, 
    onSearch: () -> Unit,
    changeMessage: (String) -> Unit
)
```

#### Parameters:
- **onAdd**: Navigation callback for Add Card functionality
- **onStudy**: Navigation callback for Study mode
- **onSearch**: Navigation callback for Search/Management  
- **changeMessage**: Function to update global message display

### 2. UI Layout
- **Column Layout**: Vertically arranged buttons with consistent spacing
- **Center Alignment**: All buttons horizontally centered
- **Spacing**: 16.dp between buttons for touch-friendly interface
- **Material Design**: Uses Material3 Button and Text components

### 3. Navigation Buttons
1. **Study Button**: 
   - Label: "Study"
   - Action: Triggers onStudy() callback
   - Content Description: "Study" for accessibility

2. **Add Button**:
   - Label: "Add" 
   - Action: Triggers onAdd() callback
   - Content Description: "Add" for accessibility

3. **Search Button**:
   - Label: "Search"
   - Action: Triggers onSearch() callback  
   - Content Description: "Search" for accessibility

## Dependencies (Classes it Uses)
- **Compose Foundation**: For layout components (Column, Arrangement)
- **Material3**: For UI components (Button, Text)
- **Compose Runtime**: For LaunchedEffect and state management
- **Semantics**: For accessibility support

## Classes that Depend on This
- **Navigator.kt**: Displays MenuAnNam as the "Main" route
- **Test Classes**: Test navigation from home screen

## Key Features

### 1. Initial Message
```kotlin
LaunchedEffect(Unit) {
    changeMessage("Please, select an option.")
}
```
- Shows welcome message when screen appears
- Uses LaunchedEffect to trigger once on composition
- Message appears in Navigator's bottom bar

### 2. Accessibility Support
Each button has dual semantic descriptions:
- **Button Level**: For button interaction
- **Text Level**: For text content reading
- **Screen Reader Friendly**: All elements properly labeled
- **Testing Support**: Enables UI test automation

### 3. Clean Architecture
- **No Business Logic**: Pure UI component with callback-based navigation
- **Dependency Injection**: Receives navigation functions from parent
- **Separation of Concerns**: Only handles UI and user interaction

### 4. Material Design
- **Consistent Styling**: Uses Material3 design system
- **Touch Targets**: Buttons sized for easy touch interaction
- **Visual Hierarchy**: Clear button labels with appropriate spacing

## Navigation Flow
```
MenuAnNam (Home)
├── Study Button → StudyScreen
├── Add Button → AddScreen  
└── Search Button → SearchScreen
```

## User Experience
- **Clear Choices**: Three distinct, well-labeled options
- **Immediate Feedback**: Shows instructional message on load
- **Easy Navigation**: Large, centered buttons easy to tap
- **Consistent Layout**: Follows app's overall design patterns

## Testing Scenarios
The screen supports testing of:
- **Button Visibility**: All three buttons should be present
- **Navigation Actions**: Each button should trigger correct navigation
- **Message Display**: Initial message should appear
- **Accessibility**: Screen reader should announce all elements correctly

## Future Enhancements
- **Statistics**: Could show card count or study progress
- **Quick Actions**: Could add shortcuts to recent cards
- **User Preferences**: Could remember last-used feature
- **Onboarding**: Could include tutorial or tips for new users

## Design Rationale
- **Simple Interface**: Three-button design minimizes cognitive load
- **Feature Parity**: Each major app function gets equal visual weight
- **Accessibility First**: Comprehensive semantic labeling from start
- **Responsive Layout**: Column layout adapts to different screen sizes