# SearchScreen.md

## Overview
A comprehensive flash card management screen that displays all cards in a scrollable list with inline editing and deletion capabilities. The primary interface for managing the flash card collection.

## Purpose
- **Card Management**: View, edit, and delete existing flash cards
- **List Display**: Shows all cards in an organized, scrollable format
- **Inline Editing**: Edit cards directly in the list without navigation
- **Quick Actions**: Easy access to edit and delete functions
- **Navigation Integration**: Links to detailed card view

## Key Components

### 1. SearchScreen Composable (Main Container)
```kotlin
@Composable
fun SearchScreen(
    changeMessage: (String) -> Unit = {},
    getAllFlashCards: suspend () -> List<FlashCard> = { emptyList() },
    selectedItem: (Int) -> Unit = {},
    updateFlashCard: suspend (FlashCard) -> Unit = {},
    deleteFlashCard: suspend (FlashCard) -> Unit = {}
)
```

#### Functionality:
- **Data Loading**: Fetches all flash cards on screen entry
- **State Management**: Handles loading state and card list
- **Error Handling**: Catches and displays operation errors
- **Screen Layout**: Provides overall structure and empty state

### 2. FlashCardList Composable (List Implementation)
```kotlin
@Composable 
fun FlashCardList(
    selectedItem: (Int) -> Unit,
    flashCards: List<FlashCard>,
    onEdit: (FlashCard) -> Unit = {},
    onDelete: (FlashCard) -> Unit = {}
)
```

#### Features:
- **LazyColumn**: Efficient rendering for large lists
- **Item Keys**: Uses card UID for stable list performance
- **Dual Mode Display**: Toggle between view and edit modes
- **Action Buttons**: Edit and Delete buttons with Material Design colors

## Key Features

### 1. Inline Editing System
```kotlin
var isEditing by remember { mutableStateOf(false) }
var editEnglish by remember { mutableStateOf(flashCard.englishCard ?: "") }
var editVietnamese by remember { mutableStateOf(flashCard.vietnameseCard ?: "") }
```

#### Edit Mode:
- **Text Fields**: Separate inputs for English and Vietnamese
- **Save Button**: Green button to commit changes
- **Cancel Button**: Gray button to discard changes
- **State Reset**: Restores original values on cancel

#### View Mode:
- **Card Display**: Shows "English = Vietnamese" format
- **Click Navigation**: Tap card to view details
- **Action Buttons**: Edit (Primary color) and Delete (Error color) buttons

### 2. Data Operations
- **Load Cards**: Fetches all cards from database on screen entry
- **Update Cards**: Saves edited cards and refreshes list
- **Delete Cards**: Removes cards and refreshes list
- **Error Handling**: Shows user-friendly error messages

### 3. State Management
- **Loading State**: Shows "Loading flash cards..." during data fetch
- **Empty State**: Shows "No flash cards found. Add some cards first!" when no data
- **Error State**: Displays specific error messages in global message area

### 4. UI/UX Design
- **Material Design**: Uses Material3 color scheme for buttons
- **Responsive Layout**: Row layout with weight distribution
- **Visual Hierarchy**: Border around cards, proper spacing
- **Touch Targets**: Appropriate button sizes for mobile interaction

## Dependencies (Classes it Uses)
- **FlashCard**: Entity for displaying and editing card data
- **Material3 Components**: Button, TextField, Text, LazyColumn
- **Compose Runtime**: For state management and coroutines
- **MaterialTheme**: For consistent color scheme

## Classes that Depend on This
- **Navigator.kt**: Includes SearchScreen in navigation as "Search" route
- **MainActivity**: Provides database operation lambdas
- **ShowCardScreen**: Accessed via selectedItem navigation callback

## Data Flow

### 1. Screen Loading
1. Screen appears → shows initial message
2. LaunchedEffect triggers → calls getAllFlashCards()
3. Data loads → updates flashCards state
4. UI renders → displays list or empty state

### 2. Edit Operation
1. User clicks "Edit" → switches to edit mode
2. User modifies text → updates local state
3. User clicks "Save" → calls updateFlashCard()
4. Database updates → refreshes card list
5. Success message shown → returns to view mode

### 3. Delete Operation
1. User clicks "Delete" → calls deleteFlashCard()
2. Database removes card → refreshes card list
3. Success message shown → list updates

## Accessibility Features
- **Semantic Structure**: Proper heading and content organization
- **Button Labels**: Clear text labels for all actions
- **Screen Reader Support**: LazyColumn provides proper focus management
- **Touch Targets**: Buttons sized appropriately for touch interaction

## Performance Considerations
- **LazyColumn**: Only renders visible items for memory efficiency
- **Item Keys**: Uses stable UIDs for efficient list updates
- **State Hoisting**: Minimal re-composition on state changes
- **Coroutine Scope**: Non-blocking database operations

## Error Scenarios
- **Network/Database Errors**: Shows error messages in global message area
- **Empty Data**: Graceful empty state with helpful message
- **Update Failures**: Preserves edit mode, shows specific error message
- **Delete Failures**: Maintains list state, shows error feedback

## Future Enhancements
- **Search Functionality**: Filter cards by text content
- **Sort Options**: Sort by date, alphabetical, or frequency
- **Batch Operations**: Select multiple cards for bulk actions
- **Swipe Actions**: Swipe to edit or delete for better UX
- **Card Statistics**: Show usage count or last studied date