# Navigator.md

## Overview
The central navigation hub that manages screen transitions and provides the main UI structure using Jetpack Compose Navigation. Contains the `AppNavigation` composable function.

## Purpose
- **Navigation Management**: Handles routing between all app screens
- **UI Structure**: Provides common UI elements (TopBar, BottomBar, Scaffold)
- **State Management**: Manages global app state like messages
- **Screen Orchestration**: Connects all screens with proper data flow

## Key Components

### 1. AppNavigation Composable
Main navigation function that sets up:
- Navigation controller routing
- Common UI structure (Scaffold with TopBar/BottomBar)
- Message display system
- Screen-specific navigation functions

### 2. Navigation Functions
Creates helper functions for screen navigation:
- `navigateToAdd()`: Navigate to Add Card screen
- `navigateToStudy()`: Navigate to Study screen  
- `navigateToSearch()`: Navigate to Search screen
- `navigateToShowCard(cardId)`: Navigate to Show Card with specific ID

### 3. UI Structure
- **Scaffold**: Main layout container
- **TopAppBar**: Shows app title and back navigation
- **BottomAppBar**: Displays messages to user
- **NavHost**: Contains all screen definitions

## Screen Routes
Defines navigation destinations:
- `"Main"` → MenuAnNam (home screen)
- `"Add"` → AddScreen (add new cards)
- `"Study"` → StudyScreen (study mode)
- `"Search"` → SearchScreen (search and manage cards)
- `"ShowCard/{cardId}"` → ShowCardScreen (view specific card)

## Dependencies (Classes it Uses)
- **MenuAnNam**: Home/main screen component (MenuScreen.kt)
- **AddScreen**: Add new flash cards screen
- **StudyScreen**: Study mode screen
- **SearchScreen**: Search and management screen
- **ShowCardScreen**: Individual card display screen
- **FlashCard**: Entity for passing between screens
- **MaterialTheme**: For UI theming

## Classes that Depend on This
- **MainActivity**: Creates and launches AppNavigation
- **Test classes**: Use for navigation testing

## Key Features

### 1. Centralized Message System
- `message` state variable shared across all screens
- `changeMessage` function passed to all screens
- Messages displayed in bottom bar

### 2. Back Navigation
- Conditional back button in top bar
- Only shows when not on main screen
- Uses `navController.navigateUp()`

### 3. Parameter Passing
- ShowCard route accepts `cardId` parameter
- Uses NavArgument for type-safe parameter passing
- Extracts parameters in composable lambda

### 4. Semantic Accessibility
- Navigation elements have content descriptions
- Supports screen readers and testing
- Uses `semantics { contentDescription = "..." }`

## Data Flow
1. MainActivity provides database operation lambdas
2. AppNavigation receives and distributes these functions
3. Each screen gets relevant operations (insert, get, delete, update)
4. Navigation functions trigger screen transitions
5. Message system provides user feedback

## State Management
- **Message State**: Global message shown in bottom bar
- **Navigation State**: Current route tracked by NavController
- **Parameter State**: Route parameters passed between screens

## UI/UX Features
- **Consistent Header**: App title always visible
- **Context-Aware Back Button**: Only shows when needed
- **Message Area**: Persistent feedback area in bottom bar
- **Material Design**: Uses Material 3 components and theming