# MenuDatabase.md

## Overview
Room database configuration class that defines the database structure, version, and provides access to DAOs (Data Access Objects).

## Purpose
- **Database Configuration**: Defines database metadata and settings
- **DAO Provider**: Creates and provides access to FlashCardDao
- **Schema Definition**: Specifies entities and database version
- **Room Integration**: Integrates with Android Room persistence library

## Key Components

### 1. Database Declaration
```kotlin
@Database(entities = [FlashCard::class], version = 1)
abstract class MenuDatabase : RoomDatabase()
```

#### Configuration:
- **Entities**: Contains FlashCard entity
- **Version**: Database schema version 1
- **Type**: Extends RoomDatabase for Room framework integration

### 2. DAO Access
```kotlin
abstract fun flashCardDao(): FlashCardDao
```
- Provides access to FlashCardDao interface
- Room automatically implements this method
- Returns concrete implementation of DAO interface

## Dependencies (Classes it Uses)
- **RoomDatabase**: Android Room base database class
- **FlashCard**: Entity class for database table
- **FlashCardDao**: Data access interface
- **Room Annotations**: @Database annotation for configuration

## Classes that Depend on This
- **MainActivity**: Creates database instance using Room.databaseBuilder
- **Test Classes**: Create in-memory instances for testing
- **Any class needing database access**: Through MainActivity's dependency injection

## Room Framework Integration

### 1. Entity Management
- Automatically creates "FlashCards" table from FlashCard entity
- Handles schema generation from entity annotations
- Manages primary keys, indexes, and constraints

### 2. DAO Implementation
- Room generates concrete implementation of FlashCardDao
- Converts @Query annotations to actual SQL
- Handles parameter binding and result mapping

### 3. Type Converters
- Automatically handles Kotlin/SQL type conversions
- Manages nullable types appropriately
- Provides compile-time SQL validation

## Database Creation Process
1. **MainActivity** calls `Room.databaseBuilder()`
2. **MenuDatabase.class** provides configuration
3. **Room** reads @Database annotation
4. **Room** creates concrete database implementation
5. **Room** generates DAO implementations
6. **Database instance** is returned to MainActivity

## Configuration Features

### 1. Version Management
- Current version: 1
- Room handles migrations between versions
- Schema changes require version increment

### 2. Entity Registration
- FlashCard entity is registered with database
- Room creates corresponding table automatically
- Entity changes require database version update

### 3. DAO Registration
- FlashCardDao is accessible through abstract method
- Room provides implementation at runtime
- Multiple DAOs can be added as needed

## Development vs Production

### Current Configuration (Development)
```kotlin
Room.databaseBuilder(context, MenuDatabase::class.java, "menuDatabase")
    .allowMainThreadQueries()  // Development only!
    .build()
```

### Production Configuration (Recommended)
```kotlin
Room.databaseBuilder(context, MenuDatabase::class.java, "menuDatabase")
    .addMigrations(/* migration strategies */)
    .build()
// Remove allowMainThreadQueries() for better performance
```

## Database Name
- **File Name**: "menuDatabase"
- **Location**: App's private database directory
- **Format**: SQLite database file

## Extension Possibilities
To add new features, you would:
1. Add new entities to @Database entities array
2. Create new DAO interfaces
3. Add abstract DAO accessor methods
4. Increment version number
5. Add migration strategies if needed

## Error Handling
- **Schema Validation**: Room validates schema at compile time
- **Type Safety**: Prevents runtime SQL errors
- **Migration Support**: Handles database upgrades gracefully

## Testing Support
- **In-Memory Database**: Can create test databases that don't persist
- **DAO Testing**: Easy to test individual DAO operations
- **Schema Testing**: Room can validate migrations automatically