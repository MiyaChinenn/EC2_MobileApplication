# FlashCardDao

## Overview
Data Access Object (DAO) interface for FlashCard entity operations in Room database.

## Package
`com.example.menuannam.data.database`

## Purpose
Defines database operations for FlashCard entities including CRUD operations.

## Methods

### `@Query("SELECT * FROM flashcard")`
- **Function**: `suspend fun getAll(): List<FlashCard>`
- **Purpose**: Retrieves all flash cards from the database
- **Returns**: List of all FlashCard entities

### `@Query("SELECT * FROM flashcard WHERE uid = :id")`
- **Function**: `suspend fun getById(id: Int): FlashCard?`
- **Purpose**: Retrieves a specific flash card by its unique ID
- **Parameters**: `id: Int` - The unique identifier of the flash card
- **Returns**: FlashCard entity or null if not found

### `@Insert`
- **Function**: `suspend fun insert(flashCard: FlashCard)`
- **Purpose**: Inserts a new flash card into the database
- **Parameters**: `flashCard: FlashCard` - The flash card entity to insert

### `@Delete`
- **Function**: `suspend fun delete(flashCard: FlashCard)`
- **Purpose**: Deletes a flash card from the database
- **Parameters**: `flashCard: FlashCard` - The flash card entity to delete

### `@Query("UPDATE flashcard SET english_card = :englishCard, vietnamese_card = :vietnameseCard WHERE uid = :id")`
- **Function**: `suspend fun update(id: Int, englishCard: String, vietnameseCard: String)`
- **Purpose**: Updates an existing flash card's content
- **Parameters**: 
  - `id: Int` - The unique identifier of the flash card to update
  - `englishCard: String` - New English text
  - `vietnameseCard: String` - New Vietnamese text

## Dependencies
- Room Database annotations (`@Dao`, `@Query`, `@Insert`, `@Delete`)
- FlashCard entity from `com.example.menuannam.data.entity`

## Usage
This DAO is used by MenuDatabase to provide database operations for the FlashCard entity. All operations are suspend functions to support coroutine-based database access.