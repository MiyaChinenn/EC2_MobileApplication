# MainActivity.md

## Overview
The entry point of the MenuAnNam flash card application. This activity sets up the entire application structure, initializes the database, and provides navigation.

## Purpose
- **Application Entry Point**: Main activity that starts when the app launches
- **Database Setup**: Creates and configures the Room database
- **Dependency Injection**: Provides database operations as lambda functions to the UI layer
- **Theme Application**: Applies the MenuAnNam theme to the entire app

## Key Responsibilities

### 1. Database Initialization
- Creates `MenuDatabase` using Room.databaseBuilder
- Allows main thread queries for simplicity (development setting)
- Initializes with test data (test11/test10 flash card)

### 2. Database Operations Setup
Creates wrapper functions for all database operations:
- `insertFlashCard`: Inserts new flash cards with error handling
- `getAllFlashCards`: Retrieves all flash cards
- `getFlashCardById`: Gets specific flash card by ID
- `deleteFlashCard`: Removes flash cards
- `updateFlashCard`: Modifies existing flash cards

### 3. Navigation Setup
- Creates `NavController` for navigation between screens
- Passes navigation controller to `AppNavigation`

## Dependencies (Classes it Uses)
- **MenuDatabase**: Database configuration class
- **FlashCard**: Entity representing flash cards
- **FlashCardDao**: Database access object for operations
- **AppNavigation**: Main navigation component
- **MenuAnNamTheme**: UI theme configuration

## Classes that Depend on This
- **None directly** (this is the entry point)

## Key Features
- **Error Handling**: All database operations include try-catch with logging
- **Logging**: Extensive logging for debugging database operations
- **Edge-to-Edge UI**: Enables modern Android UI edge-to-edge display
- **Development Setup**: Includes test data initialization for development

## Data Flow
1. User opens app → MainActivity.onCreate()
2. Database is created and initialized
3. Test data is inserted
4. Database operation lambdas are created
5. Navigation controller is set up
6. AppNavigation is launched with all dependencies

## Error Handling
- All database operations wrapped in try-catch blocks
- Exceptions are logged and re-thrown to preserve error propagation
- Uses Android Log.d for debug info and Log.e for errors

## Configuration Notes
- `allowMainThreadQueries()` is used for development simplicity
- Should be removed in production for better performance
- Database name: "menuDatabase"