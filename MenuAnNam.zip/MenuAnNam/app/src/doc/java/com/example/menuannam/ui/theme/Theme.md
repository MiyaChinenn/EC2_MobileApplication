# Theme.md

## Overview
The main theme configuration file that defines the MenuAnNam app's visual appearance using Material Design 3. Manages color schemes, dynamic theming, and dark/light mode support.

## Purpose
- **Visual Identity**: Establishes consistent app-wide styling
- **Material Design 3**: Implements latest Material Design guidelines
- **Dynamic Theming**: Supports Android 12+ dynamic color extraction
- **Accessibility**: Provides proper contrast and dark mode support

## Key Components

### 1. MenuAnNamTheme Composable
```kotlin
@Composable
fun MenuAnNamTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
)
```

#### Parameters:
- **darkTheme**: Boolean to control dark/light theme (defaults to system preference)
- **dynamicColor**: Boolean to enable Material You dynamic colors (Android 12+)
- **content**: Composable content to apply theme to

#### Features:
- **System Integration**: Automatically detects system theme preference
- **Dynamic Color Support**: Uses wallpaper colors on compatible devices
- **Fallback Support**: Graceful degradation on older Android versions

### 2. Color Scheme Definitions

#### Dark Color Scheme
```kotlin
private val DarkColorScheme = darkColorScheme(
    primary = Purple80,      // Light purple for dark backgrounds
    secondary = PurpleGrey80, // Light grey-purple for dark backgrounds
    tertiary = Pink80        // Light pink for dark backgrounds
)
```

#### Light Color Scheme
```kotlin
private val LightColorScheme = lightColorScheme(
    primary = Purple40,      // Dark purple for light backgrounds
    secondary = PurpleGrey40, // Dark grey-purple for light backgrounds  
    tertiary = Pink40        // Dark pink for light backgrounds
)
```

## Dependencies (Classes it Uses)
- **Color.kt**: Imports Purple40/80, PurpleGrey40/80, Pink40/80 color definitions
- **Type.kt**: Imports Typography configuration
- **Material3**: Material Design 3 theming system
- **Platform APIs**: System theme detection and dynamic color extraction

## Classes that Depend on This
- **MainActivity**: Applies MenuAnNamTheme to entire app content
- **All UI Components**: Inherit styling through MaterialTheme
- **Test Classes**: May use theme for UI testing scenarios

## Theme Logic

### 1. Color Scheme Selection
```kotlin
val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> DarkColorScheme
    else -> LightColorScheme
}
```

#### Decision Tree:
1. **Android 12+ with Dynamic Color**: Use system-extracted colors from wallpaper
2. **Dark Theme**: Use DarkColorScheme with light colors
3. **Light Theme**: Use LightColorScheme with dark colors

### 2. MaterialTheme Application
```kotlin
MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
)
```

#### Theme Components:
- **ColorScheme**: Selected color palette
- **Typography**: Text styling from Type.kt
- **Content**: App UI content with theme applied

## Dynamic Color Support

### 1. Material You Integration (Android 12+)
- **dynamicDarkColorScheme()**: Extracts dark theme colors from wallpaper
- **dynamicLightColorScheme()**: Extracts light theme colors from wallpaper
- **Context Required**: Needs Android context for color extraction
- **Automatic Adaptation**: Colors change when wallpaper changes

### 2. Fallback Behavior (Android 11 and below)
- **Static Colors**: Uses predefined Purple/Pink color scheme
- **Consistent Experience**: Same appearance across all devices
- **No System Dependencies**: Works without dynamic color APIs

## Color Scheme Properties

### 1. Material 3 Color Tokens
The color schemes provide these standard Material 3 tokens:
- **primary**: Main brand color for primary actions
- **onPrimary**: Text/icons on primary color surfaces
- **primaryContainer**: Containers with primary color
- **onPrimaryContainer**: Text/icons on primary containers
- **secondary**: Secondary brand color
- **onSecondary**: Text/icons on secondary surfaces
- **tertiary**: Accent color for highlights
- **error**: System error color
- **background**: Main background color
- **surface**: Component surface color

### 2. Current Usage in App
```kotlin
// Examples of color usage across the app:

// TopAppBar in Navigator
TopAppBar(
    colors = topAppBarColors(
        containerColor = MaterialTheme.colorScheme.primaryContainer,
        titleContentColor = MaterialTheme.colorScheme.primary
    )
)

// Edit buttons in SearchScreen  
Button(
    colors = ButtonDefaults.buttonColors(
        containerColor = MaterialTheme.colorScheme.primary
    )
)

// Delete buttons in SearchScreen
Button(
    colors = ButtonDefaults.buttonColors(
        containerColor = MaterialTheme.colorScheme.error
    )
)
```

## Accessibility Features

### 1. High Contrast Support
- **WCAG Compliance**: Color combinations meet accessibility standards
- **System Integration**: Respects OS high contrast settings
- **Dark Mode**: Proper contrast ratios in both light and dark themes

### 2. Dynamic Adaptation
- **System Theme**: Automatically adapts to user's system theme preference
- **Accessibility Services**: Compatible with screen readers and other tools
- **Font Scaling**: Typography scales with system font size preferences

## Integration with MainActivity

### 1. Theme Application
```kotlin
// MainActivity applies theme to entire app:
setContent {
    MenuAnNamTheme {
        // All app content inherits theme
        val navigation = rememberNavController()
        // ... rest of app setup
        AppNavigation(...)
    }
}
```

### 2. Theme Inheritance
- **Automatic Propagation**: All child composables inherit theme automatically
- **MaterialTheme Access**: Components use `MaterialTheme.colorScheme.*` for colors
- **Consistent Styling**: Ensures uniform appearance across all screens

## Testing Considerations

### 1. Theme Testing
```kotlin
// Can test with different theme configurations:
composeTestRule.setContent {
    MenuAnNamTheme(darkTheme = true) {
        // Test dark theme appearance
    }
}

composeTestRule.setContent {
    MenuAnNamTheme(dynamicColor = false) {
        // Test static color scheme
    }
}
```

### 2. Accessibility Testing
- **Contrast Testing**: Verify color combinations meet standards
- **Dark Mode Testing**: Test functionality in both themes
- **Dynamic Color Testing**: Test appearance with different system colors

## Future Enhancements

### 1. Theme Customization
```kotlin
// Could add user theme preferences:
MenuAnNamTheme(
    darkTheme = userPreferences.darkTheme,
    accentColor = userPreferences.accentColor,
    fontScale = userPreferences.fontScale
)
```

### 2. Brand Variations
```kotlin
// Could support multiple brand themes:
MenuAnNamTheme(
    brandVariant = BrandVariant.CLASSIC, // vs MODERN, MINIMAL
    colorIntensity = ColorIntensity.VIBRANT // vs MUTED, SUBTLE
)
```

### 3. Advanced Features
```kotlin
// Could add advanced theming:
MenuAnNamTheme(
    animatedColorTransitions = true,
    seasonalThemes = true,
    accessibilityEnhanced = true
)
```

## Performance Considerations
- **Static Schemes**: Light/dark color schemes are pre-computed
- **Dynamic Color Caching**: Android caches extracted colors
- **Minimal Recomposition**: Theme changes only recompose affected components
- **Memory Efficient**: Color objects are lightweight and reusable