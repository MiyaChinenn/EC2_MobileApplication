# ShowCardScreen.md

## Overview
A detailed view screen that displays a specific flash card with formatted layout and deletion capability. Accessed via navigation from the SearchScreen card list.

## Purpose
- **Card Details**: Show individual flash card in formatted, readable layout
- **Card Management**: Provide deletion option for specific cards
- **Navigation Destination**: Target screen for card selection from lists
- **Error Handling**: Gracefully handle missing or invalid cards

## Key Components

### 1. ShowCardScreen Composable
```kotlin
@Composable
fun ShowCardScreen(
    changeMessage: (String) -> Unit = {},
    cardId: Int,
    getFlashCardById: suspend (Int) -> FlashCard?,
    deleteFlashCard: suspend (FlashCard) -> Unit,
    onCardDeleted: () -> Unit = {}
)
```

#### Parameters:
- **changeMessage**: Function to update global message display
- **cardId**: Unique identifier for card to display
- **getFlashCardById**: Database operation to fetch card data
- **deleteFlashCard**: Database operation to remove card
- **onCardDeleted**: Callback for post-deletion navigation

### 2. State Management
```kotlin
var flashCard by remember { mutableStateOf<FlashCard?>(null) }
var isLoading by remember { mutableStateOf(true) }
var errorMessage by remember { mutableStateOf<String?>(null) }
```

#### State Variables:
- **flashCard**: Holds loaded card data (nullable)
- **isLoading**: Controls loading state display
- **errorMessage**: Stores error messages for display

## Key Features

### 1. Data Loading
```kotlin
LaunchedEffect(cardId) {
    try {
        isLoading = true
        flashCard = getFlashCardById(cardId)
        if (flashCard == null) {
            errorMessage = "Flash card not found"
        }
    } catch (e: Exception) {
        errorMessage = "Error loading flash card: ${e.message}"
    } finally {
        isLoading = false
    }
}
```

#### Loading Process:
- Triggers automatically when cardId changes
- Sets loading state during database operation
- Handles both null results and exceptions
- Updates global message with status

### 2. Card Display Layout
```kotlin
Card(
    modifier = Modifier.fillMaxWidth(),
    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
) {
    // Card header with ID
    Text("Flash Card #${flashCard!!.uid}")
    
    // English section
    Text("English:", style = labelLarge, fontWeight = Medium)
    Text(flashCard!!.englishCard ?: "N/A")
    
    // Vietnamese section  
    Text("Vietnamese:", style = labelLarge, fontWeight = Medium)
    Text(flashCard!!.vietnameseCard ?: "N/A")
}
```

#### Design Features:
- **Material Card**: Elevated card container for visual hierarchy
- **Typography Hierarchy**: Different text styles for labels vs content
- **Null Safety**: Shows "N/A" for missing content
- **Consistent Spacing**: 12dp spacing between sections

### 3. Delete Functionality
```kotlin
Button(
    onClick = {
        coroutineScope.launch {
            try {
                deleteFlashCard(flashCard!!)
                changeMessage("Flash card deleted successfully")
                onCardDeleted() // Navigate back
            } catch (e: Exception) {
                changeMessage("Error deleting flash card: ${e.message}")
            }
        }
    }
) {
    Text("Delete")
}
```

#### Delete Process:
- Calls database delete operation
- Shows success/error message
- Navigates back to previous screen on success
- Maintains current screen on error

## Dependencies (Classes it Uses)
- **FlashCard**: Entity for displaying card data
- **Material3 Components**: Card, Button, Text for UI
- **Compose Runtime**: For state management and coroutines
- **MaterialTheme**: For typography and color scheme

## Classes that Depend on This
- **Navigator.kt**: Defines route "ShowCard/{cardId}" for this screen
- **SearchScreen.kt**: Navigates to this screen via selectedItem callback
- **MainActivity**: Provides database operation lambdas

## UI States

### 1. Loading State
```kotlin
if (isLoading) {
    Text("Loading flash card...")
}
```
- Shows while fetching card data
- Prevents UI flickering during load
- Simple text indicator

### 2. Error State
```kotlin
else if (errorMessage != null) {
    Text(
        text = errorMessage!!,
        color = MaterialTheme.colorScheme.error
    )
}
```
- Displays specific error messages
- Uses error color from theme
- Handles both "not found" and exception cases

### 3. Success State
- Shows formatted card with Material Design card
- Displays card ID, English text, Vietnamese text
- Provides delete button for card management

## Navigation Integration

### 1. Route Parameters
- Receives cardId through navigation arguments
- Route pattern: "ShowCard/{cardId}" 
- cardId must be valid integer

### 2. Navigation Callbacks
- **onCardDeleted()**: Called after successful deletion
- Usually triggers `navController.navigateUp()` to return to list
- Allows parent screen to handle navigation logic

### 3. Error Navigation
- Stays on current screen for errors
- Shows error in global message area
- User can use back button to return

## Error Handling

### 1. Card Not Found
- Database returns null for invalid cardId
- Shows "Flash card not found" error
- Updates global message for user feedback

### 2. Database Exceptions
- Network, database, or permission errors
- Shows "Error loading flash card: [details]"
- Preserves error details for debugging

### 3. Delete Failures
- Database constraint or connection errors
- Shows specific error message
- Maintains screen state for retry

## Accessibility Features
- **Typography Scale**: Uses Material Design typography tokens
- **Color Contrast**: Error text uses theme error color
- **Content Structure**: Clear hierarchy with labels and content
- **Button Accessibility**: Standard Material button with text label

## Future Enhancements

### 1. Edit Functionality
```kotlin
// Could add inline editing:
- Edit button alongside delete
- Toggle to edit mode with text fields
- Save/cancel buttons for modifications
```

### 2. Study Integration
```kotlin
// Could integrate with study features:
- "Study this card" button
- Mark as "difficult" or "mastered"
- Show study statistics for this card
```

### 3. Navigation Improvements
```kotlin
// Could add better navigation:
- Previous/Next buttons to browse cards
- Share card content
- Favorite/bookmark functionality
```

### 4. Rich Content
```kotlin
// Could support multimedia:
- Audio pronunciation
- Images or examples
- Rich text formatting
```