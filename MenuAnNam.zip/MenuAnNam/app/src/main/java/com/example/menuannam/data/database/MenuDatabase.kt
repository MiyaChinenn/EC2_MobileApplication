package com.example.menuannam.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.menuannam.data.entity.FlashCard

@Database(entities = [FlashCard::class], version = 1)
abstract class MenuDatabase : RoomDatabase() {
    abstract fun flashCardDao(): FlashCardDao
}