package com.example.menuannam.presentation.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

@Composable
fun MenuAnNam(
    onAdd: () -> Unit,
    onStudy: () -> Unit,
    onSearch: () -> Unit,
    onLogin: () -> Unit,
    changeMessage: (String) -> Unit
) {
    LaunchedEffect(Unit) {
        changeMessage("Please, select an option.")
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {

        Button(modifier = Modifier.semantics{contentDescription="navigateToStudy"},
            onClick = {
                onStudy()
            })
        { Text("Study Cards", modifier = Modifier.semantics{contentDescription="Study"},) }
        Button(modifier = Modifier.semantics{contentDescription="navigateToAdd"},
            onClick = {
                onAdd()
            }) {
            Text("Add Card", modifier = Modifier.semantics{contentDescription="Add"},)
        }
        Button(modifier = Modifier.semantics{contentDescription="navigateToSearch"},onClick = {
            onSearch()
        }) { Text("Search Cards", modifier = Modifier.semantics{contentDescription="Search"},) }
        Button(modifier = Modifier.semantics{contentDescription="navigateToLogin"},onClick = {
            onLogin()
        }) { Text("Log in", modifier = Modifier.semantics{contentDescription="Login"},) }

    }
}