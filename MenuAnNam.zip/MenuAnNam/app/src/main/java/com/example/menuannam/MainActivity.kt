package com.example.menuannam

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.navigation.compose.rememberNavController
import androidx.room.Room
import com.example.menuannam.ui.theme.MenuAnNamTheme
import kotlinx.coroutines.runBlocking
import com.example.menuannam.data.entity.FlashCard
import com.example.menuannam.data.database.MenuDatabase
import com.example.menuannam.presentation.navigation.AppNavigation
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import com.example.menuannam.data.network.NetworkService

val retrofit: Retrofit = Retrofit.Builder()
    .baseUrl("https://dmzrueciplycef2h5r7ipqbf4y0hhpse.lambda-url.ap-southeast-1.on.aws/")
    .addConverterFactory(GsonConverterFactory.create())
    .build()

val networkService = retrofit.create(NetworkService::class.java)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()
        setContent {
            MenuAnNamTheme{
                val navigation = rememberNavController()
                val db = Room.databaseBuilder(
                    applicationContext,
                    MenuDatabase::class.java, "menuDatabase"
                ).allowMainThreadQueries()  // Allow main thread queries for simplicity
                 .build()
                val flashCardDao = db.flashCardDao()
                val insertFlashCard: suspend (FlashCard) -> Unit = { flashCard ->
                    try {
                        Log.d("MainActivity", "Inserting FlashCard: $flashCard")
                        flashCardDao.insert(flashCard)
                        Log.d("MainActivity", "FlashCard inserted successfully")
                    } catch (e: Exception) {
                        Log.e("MainActivity", "Error inserting FlashCard", e)
                        throw e
                    }
                }
                
                val getAllFlashCards: suspend () -> List<FlashCard> = {
                    try {
                        Log.d("MainActivity", "Getting all FlashCards")
                        flashCardDao.getAll()
                    } catch (e: Exception) {
                        Log.e("MainActivity", "Error getting all FlashCards", e)
                        throw e
                    }
                }
                
                val getFlashCardById: suspend (Int) -> FlashCard? = { id ->
                    try {
                        Log.d("MainActivity", "Getting FlashCard by ID: $id")
                        flashCardDao.getById(id)
                    } catch (e: Exception) {
                        Log.e("MainActivity", "Error getting FlashCard by ID", e)
                        throw e
                    }
                }
                
                val deleteFlashCard: suspend (FlashCard) -> Unit = { flashCard ->
                    try {
                        Log.d("MainActivity", "Deleting FlashCard: $flashCard")
                        flashCardDao.delete(flashCard)
                        Log.d("MainActivity", "FlashCard deleted successfully")
                    } catch (e: Exception) {
                        Log.e("MainActivity", "Error deleting FlashCard", e)
                        throw e
                    }
                }
                
                val updateFlashCard: suspend (FlashCard) -> Unit = { flashCard ->
                    try {
                        Log.d("MainActivity", "Updating FlashCard: $flashCard")
                        flashCardDao.update(flashCard.uid, flashCard.englishCard ?: "", flashCard.vietnameseCard ?: "")
                        Log.d("MainActivity", "FlashCard updated successfully")
                    } catch (e: Exception) {
                        Log.e("MainActivity", "Error updating FlashCard", e)
                        throw e
                    }
                }
                
                // Initialize with test data
                try {
                    runBlocking {
                        flashCardDao.insert(FlashCard(
                            uid = 0,
                            englishCard = "test11",
                            vietnameseCard = "test10"
                        ))
                        val flashCards = flashCardDao.getAll()
                        Log.d("AnNam123", "Initial flashcards: $flashCards")
                    }
                } catch (e: Exception) {
                    Log.e("MainActivity", "Error initializing database", e)
                }
                
                AppNavigation(
                    navigation,
                    insertFlashCard,
                    getAllFlashCards,
                    getFlashCardById,
                    deleteFlashCard,
                    updateFlashCard,
                    networkService
                )
            }
        }
    }
}








