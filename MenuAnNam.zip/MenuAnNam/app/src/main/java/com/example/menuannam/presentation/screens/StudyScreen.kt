package com.example.menuannam.presentation.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.menuannam.data.entity.FlashCard
import kotlinx.coroutines.launch

@Composable
fun StudyScreen(
    changeMessage: (String) -> Unit = {},
    getAllFlashCards: suspend () -> List<FlashCard> = { emptyList() }
) {
    var lesson by remember { mutableStateOf<List<FlashCard>>(emptyList()) }
    var currentIndex by remember { mutableStateOf(0) }
    var showVietnamese by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        scope.launch {
            try {
                val allCards = getAllFlashCards()
                lesson = if (allCards.size >= 5) {
                    allCards.shuffled().take(5)
                } else {
                    allCards
                }
                changeMessage("Study your lesson: ${lesson.size} flashcards")
            } catch (e: Exception) {
                changeMessage("Error loading flashcards: ${e.message}")
            }
        }
    }

    if (lesson.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("Loading flashcards...")
        }
    } else {
        val currentCard = lesson[currentIndex]
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically)
        ) {
            Text(
                text = "Card ${currentIndex + 1} of ${lesson.size}",
                style = MaterialTheme.typography.titleMedium
            )
            
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clickable {
                        showVietnamese = !showVietnamese
                    },
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (showVietnamese) {
                            currentCard.vietnameseCard ?: ""
                        } else {
                            currentCard.englishCard ?: ""
                        },
                        fontSize = 32.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(32.dp)
                    )
                }
            }
            
            if (showVietnamese) {
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        currentIndex = (currentIndex + 1) % lesson.size
                        showVietnamese = false
                        changeMessage("Card ${currentIndex + 1} of ${lesson.size}")
                    }
                ) {
                    Text("Next")
                }
            }
        }
    }
}