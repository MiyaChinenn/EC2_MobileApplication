package com.example.menuannam.presentation.screens

import android.util.Log
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import kotlinx.coroutines.launch
import com.example.menuannam.data.entity.FlashCard


@Composable
fun AddScreen(
    changeMessage: (String) -> Unit,
    insertFlashCard: suspend (FlashCard) -> Unit
) {
    var enWord by rememberSaveable {mutableStateOf("")}
    var vnWord by rememberSaveable {mutableStateOf("")}
    val coroutineScope = rememberCoroutineScope()
    
    LaunchedEffect(Unit) {
        changeMessage("Please, add a flash card.")
    }

    Column() {
        TextField(
            value = enWord,
            onValueChange = { enWord = it },
            modifier = Modifier.semantics { contentDescription = "enTextField" },
            label = { Text("en") }
        )
        TextField(
            value = vnWord,
            onValueChange = { vnWord = it },
            modifier = Modifier.semantics { contentDescription = "vnTextField" },
            label = { Text("vn") }
        )
        Button(
            modifier = Modifier.semantics { contentDescription = "Add" },
            onClick = {
                Log.d("AddScreen", "Button clicked - enWord: '$enWord', vnWord: '$vnWord'")
                coroutineScope.launch {
                    try {
                        Log.d("AddScreen", "Attempting to insert FlashCard")
                        insertFlashCard(FlashCard(uid = 0, englishCard = enWord, vietnameseCard = vnWord))
                        Log.d("AddScreen", "FlashCard inserted successfully")
                        // Clear the form after successful addition
                        enWord = ""
                        vnWord = ""
                        changeMessage("Card added successfully!")
                    } catch (e: Exception) {
                        Log.e("AddScreen", "Error inserting FlashCard", e)
                        val errorMessage = e.message ?: e.javaClass.name
                        changeMessage("Error adding card: $errorMessage")
                    }
                }
            })
        {
            Text("Add")
        }
    }
}